# Video Affiliate Page — Cloudflare Pages

Alur: X/Twitter → halaman video → tombol Shopee Affiliate.

## Ganti
1. video/video.mp4 dengan video kamu.
2. images/thumbnail.jpg dengan thumbnail kamu.
3. GANTI_DENGAN_LINK_SHOPEE_AFFILIATE di index.html dengan link affiliate kamu.
4. Setelah mendapat URL Pages, ganti YOUR-PROJECT.pages.dev pada og:image dan twitter:image.

Deploy ke Cloudflare Pages dari GitHub. Build command kosong; output root `/`.

Catatan: metadata mengontrol judul/deskripsi/thumbnail yang dapat dibaca crawler; X menentukan format card akhirnya.
